from flask import Flask, render_template, request
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from ultralytics import YOLO
from PIL import Image
import torch
import os
import uuid

# Init Flask
app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Device
device = "cuda" if torch.cuda.is_available() else "cpu"

# Load models
yolo_model = YOLO("yolov8s.pt")
all_classes = yolo_model.names

phi_model_id = "microsoft/phi-2"
tokenizer = AutoTokenizer.from_pretrained(phi_model_id)
model = AutoModelForCausalLM.from_pretrained(
    phi_model_id,
    torch_dtype=torch.float16 if device == "cuda" else torch.float32
).to(device)
text_gen = pipeline("text-generation", model=model, tokenizer=tokenizer, device=0 if device == "cuda" else -1)

product_classes = ["cell phone", "laptop"]

# Routes
@app.route("/", methods=["GET", "POST"])
def index():
    result = {}
    if request.method == "POST":
        image = request.files["image"]
        if image:
            image_id = str(uuid.uuid4()) + os.path.splitext(image.filename)[1]
            image_path = os.path.join(UPLOAD_FOLDER, image_id)
            image.save(image_path)

            results = yolo_model(image_path)
            detections = results[0].boxes.cls.tolist()
            detected_labels = list(set([all_classes[int(c)] for c in detections]))
            filtered_labels = [label for label in detected_labels if label in product_classes]

            product_info = []
            for label in filtered_labels:
                title_prompt = f"""You are a creative product branding expert.

Generate a catchy and brandable product title for the following item.
Avoid using the generic word "{label}" in the title. Make it sound premium, appealing, and unique.

Product: {label}
Title:"""
                title = text_gen(title_prompt, max_new_tokens=30, temperature=0.8, top_p=0.9, do_sample=True)[0]["generated_text"][len(title_prompt):].strip()

                desc_prompt = f"""You are a skilled product marketer.

Generate a detailed, vivid and persuasive 3-5 line product description for the following item.

Product: {label}
Description:"""
                description = text_gen(desc_prompt, max_new_tokens=150, temperature=0.7, top_p=0.9, do_sample=True)[0]["generated_text"][len(desc_prompt):].strip()

                features_prompt = f"""You are a skilled product marketer.

Generate 3-5 feature bullet points for the following item.

Product: {label}
Features:"""
                features = text_gen(features_prompt, max_new_tokens=100, temperature=0.7, top_p=0.9, do_sample=True)[0]["generated_text"][len(features_prompt):].strip()

                product_info.append({
                    "label": label,
                    "title": title,
                    "description": description,
                    "features": features
                })

            result = {
                "image_path": image_path,
                "products": product_info
            }

    return render_template("index.html", result=result)
