
#  AI-Powered Product Copy Generator

This project detects product objects from images or videos using YOLOv8 and generates creative marketing content (titles, descriptions, features) using the Phi-2 language model. It uses a Flask web interface to let users upload product images and receive AI-generated copy.

---

##  Tech Stack

- Python 3.11.9
- [Ultralytics YOLOv8](https://github.com/ultralytics/ultralytics) – Object detection
- [Hugging Face Transformers](https://huggingface.co/microsoft/phi-2) – Phi-2 model for content generation
- Torch (PyTorch)
- Flask – Web application framework

---

##  Folder Structure

```
Project/
│
├── Application/                      # Main Flask app
│   ├── app.py                        # Flask application file
│   ├──  yolov8s.pt                   # YOLO model weights
│   ├── static/uploads                # Static tmp files uploads
│   ├── templates/index.py            # HTML index file
│   └── requirements.txt              # Includes project dependencies
│
├── Output-Files/                           # Output references
│   ├── Image-input-Flask-Output.pdf        # Flask app output from laptop image
│   ├── UI-Output.pdf                       # Flask app output from phone image
│   ├── Video-input-Notebook-Output.ipynb   # Notebook output from video input
│   └── Notebook-Code.pdf                   # Notebook code saved as PDF
│
├── Sample-Test-Tiles/               # Input test files
│   ├── laptop.jpg 
│   ├── phone.jpg                   # Sample product image
│   └── Cell Phone.mp4               # Sample video input
│
└── README.md                        # Project documentation
```

---

##  Setup Instructions

### 1️ Unzip this repository


### 2️ (Optional but recommended) Create and activate a virtual environment

```bash
python -m venv venv
venv\Scripts\activate   # On Windows
# or
source venv/bin/activate  # On Mac/Linux
```

### 3️ Install required dependencies

```bash
pip install -r requirements.txt
```

> If using GPU, make sure CUDA-compatible PyTorch is installed.

---

##  Running the Flask App

1. Navigate to the **Application** directory:

```bash
cd Application
```

2. Run the Flask application:

```bash
flask run
```

3. Open your browser and go to:

```
http://127.0.0.1:5000/
```

4. Upload a sample image (e.g., from `Sample-Test-Files/laptop.jpg`) to test object detection and AI-generated copy output.

---

## 📸 What It Does

- Detects product-related objects using YOLOv8 (For this assignment assumed products are laptop and cell phone) 
- Filters out common product classes like `cell phone`, `laptop`  
- Generates:

- **Catchy product titles**
- **Persuasive product descriptions**
- **Feature bullet points**

---

##  Notes

- Ensure you have the YOLOv8 model weights file `yolov8s.pt` placed inside the `Application` folder.
- Tested on **Python 3.11.9** on Windows.
- This implementation uses `Flask`.
